# SAHAARA 360

AI-powered elderly care and family coordination. A FastAPI + Postgres backend with a plain HTML/JS front end, built from the SAHAARA 360 hackathon proposal.

> Care that connects. Intelligence that protects. Independence that matters.

## What works

| Area | What it does |
|---|---|
| Accounts | Email + passcode sign-in (PBKDF2 hashed, JWT session). |
| Roles | Elderly person, family member, caregiver, each with different permissions. The owner creates one-time invite codes and can revoke or restore anyone's access. |
| Medicines | Add, remove, schedule by time of day, record taken / skipped / missed, adherence (today and 7 days), stock and refill estimate. Reminds, never orders. |
| Prescription scanner | Upload a photo, Gemini proposes a draft, a person must verify each row before it is saved. Needs `GEMINI_API_KEY`. |
| Appointments | Add, list and remove. |
| Check-ins and escalation | Start a check-in. After 15 / 30 / 60 minutes (configurable) it reminds, alerts the primary caregiver, then the secondary contact. Acknowledging stops it. |
| SOS | Notifies everyone else with access. States it is not a replacement for emergency services (112). |
| Care Gap Radar | Explainable rules over missed doses, unanswered check-ins and upcoming appointments. Never diagnoses. |
| Voice companion | Hindi/Hinglish and English questions, typed or spoken (browser speech recognition), answers read aloud, confirmation before changing records. |
| Family feed and audit | Every important change is logged with who and when. |
| Health Passport | Printable or PDF summary of authorized information. |
| Email alerts | Optional SMTP. Without it, alerts still appear inside the app. |

## Run locally

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                    # optional, defaults work
uvicorn app.main:app --reload
```

Open http://localhost:8000 for the landing page and http://localhost:8000/app.html for the app. With no `DATABASE_URL` it stores data in a local `sahaara.db` file.

Run the logic tests: `pip install pytest && pytest -q tests`.

## Deploy (free tier)

1. **Database.** Create a Supabase project. Copy the Postgres connection string (Project Settings, Database) into `DATABASE_URL`. Add `?sslmode=require` if it is missing. Tables are created on first start.
2. **Push this repo to GitHub.**
3. **Render.** New, Blueprint (it reads `render.yaml`), connect the repo. Set `DATABASE_URL` and, if you want the scanner, `GEMINI_API_KEY`. Render gives you the live link. The same service serves the API and the website, so there is nothing else to host.
4. **Scheduled job (optional but recommended).** Missed-dose alerts and automatic escalation run when this URL is called. Use cron-job.org or similar to call it every 10 minutes:
   `curl -X POST -H "X-Job-Key: <your JOB_KEY>" https://<your-app>.onrender.com/api/jobs/tick`
5. **Email (optional).** Set the `SMTP_*` variables (for example a Gmail app password or Brevo).

## Demo case

Scenario: Asha's family checks her evening routine before her cardiology visit.

1. Create two accounts in two browsers (Rohan, Neha). Rohan creates a profile for Asha (role: family member).
2. Family tab: Rohan creates a **caregiver** invite code. Neha signs in and joins with it. Revoke and restore her to show the audit feed.
3. Medicines: Rohan adds Amlodipine 5 mg at `09:00` and Metformin at `08:00,20:00`. Try the prescription scanner with a photo.
4. Today: Neha records one dose as taken and one as missed. Open Care Gap Radar to see the summary.
5. Safety: Rohan starts a check-in. Neha sees the alert after the wait, adds a follow-up note and acknowledges it. Press SOS to show the 112 warning.
6. Voice: ask "Meri agli medicine kab hai?", then "Caregiver ko update bhejo." and confirm.
7. Visits and Passport: add the appointment and print the Health Passport.

## Project layout

```
app/        FastAPI backend (models, auth, API, logic)
frontend/   index.html (landing page), app.html + app.js (the app), style.css
tests/      unit tests for the care logic
render.yaml deploy blueprint
```

## Safety and privacy

- The AI never diagnoses or changes prescriptions. Radar output is a prompt for a human.
- Scanned prescriptions are drafts and need human verification.
- Actions that change records need confirmation.
- A missing check-in response is never treated as proof of an emergency.
- This is a hackathon prototype, not a medical device. Before real use it needs a security review, rate limiting, backups and legal review of health-data rules.
