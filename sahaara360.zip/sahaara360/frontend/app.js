(function () {
  'use strict';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var esc = function (t) { return String(t == null ? '' : t).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };

  var S = { token: null, me: null, profile: null, tab: 'today', lang: 'hi', timer: null };
  try { S.token = localStorage.getItem('s360_token'); } catch (e) {}

  /* ---------- api ---------- */
  function api(path, opt) {
    opt = opt || {};
    var h = {};
    if (S.token) h['Authorization'] = 'Bearer ' + S.token;
    var body;
    if (opt.form) { body = opt.form; } else if (opt.body !== undefined) { h['Content-Type'] = 'application/json'; body = JSON.stringify(opt.body); }
    return fetch('/api' + path, { method: opt.method || 'GET', headers: h, body: body }).then(function (r) {
      return r.text().then(function (t) {
        var d = null; try { d = t ? JSON.parse(t) : null; } catch (e) {}
        if (r.status === 401 && S.token) { signOut(true); }
        if (!r.ok) {
          var m = d && d.detail;
          if (Array.isArray(m)) m = m.map(function (x) { return x.msg; }).join('. ');
          throw new Error(m || 'Something went wrong (' + r.status + ').');
        }
        return d;
      });
    });
  }
  var pp = function (p) { return '/profiles/' + S.profile.id + p; };
  var can = function (c) { return S.profile && S.profile.caps.indexOf(c) >= 0; };

  function say(el, text, kind) { el.innerHTML = text ? '<div class="msg ' + (kind || 'ok') + '">' + esc(text) + '</div>' : ''; }
  function bar(text, kind) { say($('#msgBar'), text, kind); if (text && kind !== 'err') setTimeout(function () { say($('#msgBar'), ''); }, 4000); }
  function fail(e) { bar(e.message || String(e), 'err'); }

  /* ---------- views ---------- */
  function show(v) {
    ['vAuth', 'vProfiles', 'vApp'].forEach(function (id) { $('#' + id).classList.toggle('hide', id !== v); });
    $('#logoutBtn').classList.toggle('hide', v === 'vAuth');
    $('#switchBtn').classList.toggle('hide', v !== 'vApp');
    if (v === 'vAuth') $('#crumb').textContent = 'Sign in';
    if (v === 'vProfiles') $('#crumb').textContent = S.me ? 'Hello, ' + S.me.user.name : 'Profiles';
    if (v !== 'vApp') { clearInterval(S.timer); }
  }
  function signOut(expired) {
    S.token = null; S.me = null; S.profile = null;
    try { localStorage.removeItem('s360_token'); } catch (e) {}
    show('vAuth');
    if (expired) say($('#authMsg'), 'Your session expired. Sign in again.', 'err');
  }
  function loadMe() {
    return api('/me').then(function (d) { S.me = d; return d; });
  }
  function toProfiles() {
    loadMe().then(function () {
      show('vProfiles');
      var l = S.me.profiles;
      $('#plist').innerHTML = l.length ? l.map(function (p) {
        return '<div class="pitem"><div><b style="font-size:1.1rem">' + esc(p.name) + '</b>' + (p.age ? ' <small>(' + p.age + ')</small>' : '') + '<br><span class="tag">' + esc(p.role) + (p.is_owner ? ' · owner' : '') + '</span></div><button class="btn small" data-open="' + p.id + '" type="button">Open</button></div>';
      }).join('') : '<p>No profiles yet. Create one, or join with an invite code.</p>';
      $$('[data-open]').forEach(function (b) { b.addEventListener('click', function () { openProfile(+b.getAttribute('data-open')); }); });
    }).catch(function (e) { if (!S.token) return; say($('#pMsg'), e.message, 'err'); });
  }
  function openProfile(id) {
    S.profile = S.me.profiles.filter(function (p) { return p.id === id; })[0];
    show('vApp');
    $('#crumb').textContent = S.profile.name + ' · ' + S.profile.role;
    setTab('today');
  }

  /* ---------- auth ---------- */
  var mode = 'login';
  $$('[data-auth]').forEach(function (b) {
    b.addEventListener('click', function () {
      mode = b.getAttribute('data-auth');
      $$('[data-auth]').forEach(function (x) { x.setAttribute('aria-selected', x === b ? 'true' : 'false'); });
      $('#nameRow').classList.toggle('hide', mode !== 'register');
      $('#authGo').textContent = mode === 'login' ? 'Sign in' : 'Create account';
      say($('#authMsg'), '');
    });
  });
  $('#authForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var body = { email: $('#aEmail').value, passcode: $('#aPass').value };
    if (mode === 'register') body.name = $('#aName').value;
    api('/auth/' + mode, { method: 'POST', body: body }).then(function (d) {
      S.token = d.token; try { localStorage.setItem('s360_token', d.token); } catch (x) {}
      $('#aPass').value = '';
      toProfiles();
    }).catch(function (err) { say($('#authMsg'), err.message, 'err'); });
  });
  $('#logoutBtn').addEventListener('click', function () { signOut(false); });
  $('#switchBtn').addEventListener('click', toProfiles);

  $('#pForm').addEventListener('submit', function (e) {
    e.preventDefault();
    api('/profiles', { method: 'POST', body: { name: $('#pName').value, age: $('#pAge').value ? +$('#pAge').value : null, emergency_contacts: $('#pEm').value, my_role: $('#pRole').value } })
      .then(function () { $('#pForm').reset(); say($('#pMsg'), 'Profile created.', 'ok'); toProfiles(); })
      .catch(function (err) { say($('#pMsg'), err.message, 'err'); });
  });
  $('#jForm').addEventListener('submit', function (e) {
    e.preventDefault();
    api('/invites/redeem', { method: 'POST', body: { code: $('#jCode').value } })
      .then(function () { $('#jCode').value = ''; say($('#pMsg'), 'You joined the profile.', 'ok'); toProfiles(); })
      .catch(function (err) { say($('#pMsg'), err.message, 'err'); });
  });

  /* ---------- text size ---------- */
  $$('[data-fs]').forEach(function (b) {
    b.addEventListener('click', function () {
      document.documentElement.style.fontSize = (parseFloat(b.getAttribute('data-fs')) * 100) + '%';
      $$('[data-fs]').forEach(function (x) { x.setAttribute('aria-pressed', x === b ? 'true' : 'false'); });
    });
  });

  /* ---------- tabs ---------- */
  function setTab(t) {
    S.tab = t; clearInterval(S.timer);
    $$('#appTabs .tab').forEach(function (x) { x.setAttribute('aria-selected', x.getAttribute('data-t') === t ? 'true' : 'false'); });
    say($('#msgBar'), '');
    var f = { today: tToday, meds: tMeds, radar: tRadar, voice: tVoice, family: tFamily, safety: tSafety, visits: tVisits }[t];
    $('#pane').innerHTML = '<p>Loading…</p>';
    f();
  }
  $$('#appTabs .tab').forEach(function (b) { b.addEventListener('click', function () { setTab(b.getAttribute('data-t')); }); });
  var pane = function (h) { $('#pane').innerHTML = h; };
  var H = function (t) { return '<h2 class="display" style="font-size:2.2rem;margin-bottom:12px"><span class="gtext">' + esc(t) + '</span></h2>'; };
  var pillFor = { taken: ['Taken', ''], skipped: ['Skipped', 'amber'], missed: ['Missed', 'red'], overdue: ['Overdue', 'red'], pending: ['Pending', 'grey'] };

  /* ---------- Today ---------- */
  function tToday() {
    api(pp('/schedule')).then(function (s) {
      var pct = s.adherence_7d;
      var rows = s.items.length ? s.items.map(function (i, n) {
        var p = pillFor[i.status] || pillFor.pending;
        var btns = can('record_dose') ? ['taken', 'skipped', 'missed'].map(function (k) {
          return '<button class="chip' + (i.status === k ? ' on' : '') + '" data-dose="' + n + '" data-k="' + k + '" type="button">' + pillFor[k][0] + '</button>';
        }).join('') + (['taken', 'skipped', 'missed'].indexOf(i.status) >= 0 ? '<button class="chip" data-dose="' + n + '" data-k="clear" type="button">Undo</button>' : '') : '';
        return '<div class="med"><div class="time">' + esc(i.time) + '</div><div><b>' + esc(i.name) + ' ' + esc(i.dosage) + '</b><span class="tag ' + p[1] + '">' + p[0] + '</span>' + (i.recorded_by ? '<br><small>Recorded by ' + esc(i.recorded_by) + '</small>' : '') + '</div><div class="acts">' + btns + '</div></div>';
      }).join('') : '<p>No doses scheduled today. Add medicines in the Medicines tab.</p>';
      pane(H('Today') + '<div class="two"><div class="card">' + rows + '</div><div class="card" style="text-align:center">' +
        '<div class="ring" style="--p:' + (pct || 0) + '"><div><strong>' + (pct == null ? '—' : pct + '%') + '</strong><span>last 7 days</span></div></div>' +
        '<p style="font-weight:600">' + s.taken + ' of ' + s.total + ' doses taken today</p>' +
        '<p style="margin-top:6px">' + (s.next ? 'Next: ' + esc(s.next.name) + ' ' + esc(s.next.dosage) + ' at ' + esc(s.next.time) : 'All of today\'s doses are recorded.') + '</p></div></div>');
      $$('[data-dose]').forEach(function (b) {
        b.addEventListener('click', function () {
          var i = s.items[+b.getAttribute('data-dose')];
          api(pp('/doses'), { method: 'POST', body: { medicine_id: i.medicine_id, time: i.time, day: i.day, status: b.getAttribute('data-k') } })
            .then(tToday).catch(fail);
        });
      });
    }).catch(fail);
  }

  /* ---------- Medicines ---------- */
  function tMeds() {
    api(pp('/medicines')).then(function (ms) {
      var list = ms.length ? ms.map(function (m) {
        var r = m.refill;
        return '<div class="med"><div class="time" style="min-width:0">' + esc(m.times.join(' · ')) + '</div><div><b>' + esc(m.name) + ' ' + esc(m.dosage) + '</b>' +
          (r ? '<span class="tag ' + (r.low ? 'amber' : '') + '">' + r.days_left + ' days of stock</span><br><small>May run low about ' + esc(r.run_out) + '. ' + (r.low ? 'Review a refill with the caregiver now.' : 'Reminder to review a refill on ' + esc(r.remind_on) + '.') + '</small>' : '<br><small>No stock entered</small>') +
          '</div><div class="acts">' + (can('manage_meds') ? '<button class="chip" data-del="' + m.id + '" type="button">Remove</button>' : '') + '</div></div>';
      }).join('') : '<p>No medicines yet.</p>';
      var add = can('manage_meds') ? '<div class="card sec"><h3>Add a medicine</h3><form id="mForm" class="row" style="margin-top:10px">' +
        '<label class="f" for="mName">Name<input id="mName" type="text" required></label>' +
        '<label class="f" for="mDose">Dosage<input id="mDose" type="text" placeholder="500 mg"></label>' +
        '<label class="f" for="mTimes">Times (24-hour, comma separated)<input id="mTimes" type="text" placeholder="08:00,20:00" required></label>' +
        '<label class="f" for="mStock">Tablets in stock<input id="mStock" type="number" min="0"></label>' +
        '<button class="btn small" type="submit" style="flex:0 0 auto">Add</button></form></div>' +
        '<div class="card sec"><span class="tag">AI draft</span><h3 style="margin:8px 0 4px">Prescription scanner</h3><p style="font-size:.95rem">Upload a photo. The AI proposes medicines as a draft. Nothing is saved until you check and verify each row.</p>' +
        '<div class="row" style="margin-top:10px"><label class="f" for="rxFile">Prescription image<input id="rxFile" type="file" accept="image/*"></label><button class="btn small" id="rxGo" type="button" style="flex:0 0 auto">Scan</button></div><div id="rxOut"></div></div>' : '';
      pane(H('Medicines') + '<div class="card">' + list + '</div>' + add);
      $$('[data-del]').forEach(function (b) { b.addEventListener('click', function () { if (confirm('Remove this medicine from the care plan?')) api(pp('/medicines/' + b.getAttribute('data-del')), { method: 'DELETE' }).then(tMeds).catch(fail); }); });
      var f = $('#mForm');
      if (f) f.addEventListener('submit', function (e) {
        e.preventDefault();
        api(pp('/medicines'), { method: 'POST', body: { name: $('#mName').value, dosage: $('#mDose').value, times: $('#mTimes').value.split(','), stock: $('#mStock').value ? +$('#mStock').value : null } })
          .then(function () { bar('Medicine added.'); tMeds(); }).catch(fail);
      });
      var go = $('#rxGo');
      if (go) go.addEventListener('click', scanRx);
    }).catch(fail);
  }
  function scanRx() {
    var file = $('#rxFile').files[0];
    if (!file) { say($('#rxOut'), 'Choose an image first.', 'err'); return; }
    var fd = new FormData(); fd.append('file', file);
    say($('#rxOut'), 'Reading the prescription…', 'ok');
    api(pp('/prescriptions/extract'), { method: 'POST', form: fd }).then(function (d) {
      if (!d.draft.length) { say($('#rxOut'), 'No medicines found. Add them by hand.', 'err'); return; }
      $('#rxOut').innerHTML = '<p style="margin-top:10px"><span class="tag amber">Draft</span> Check every field, tick Verified, then save.</p><table class="draft"><thead><tr><th>Medicine</th><th>Dose</th><th>Times</th><th>Verified</th></tr></thead><tbody>' +
        d.draft.map(function (r, i) {
          return '<tr><td><input type="text" data-f="n" data-i="' + i + '" value="' + esc(r.name) + '" aria-label="Medicine"></td><td><input type="text" data-f="d" data-i="' + i + '" value="' + esc(r.dosage) + '" aria-label="Dose"></td><td><input type="text" data-f="t" data-i="' + i + '" value="' + esc(r.times.join(',')) + '" aria-label="Times"></td><td><input type="checkbox" data-f="v" data-i="' + i + '" aria-label="Verified"></td></tr>';
        }).join('') + '</tbody></table><button class="btn small" id="rxSave" type="button">Save verified rows</button>';
      $('#rxSave').addEventListener('click', function () {
        var jobs = [];
        d.draft.forEach(function (r, i) {
          var g = function (k) { return $('[data-f="' + k + '"][data-i="' + i + '"]'); };
          if (!g('v').checked) return;
          jobs.push(api(pp('/medicines'), { method: 'POST', body: { name: g('n').value, dosage: g('d').value, times: g('t').value.split(',') } }));
        });
        if (!jobs.length) { say($('#rxOut'), 'Tick Verified on at least one row.', 'err'); return; }
        Promise.all(jobs).then(function () { bar('Verified medicines saved.'); tMeds(); }).catch(fail);
      });
    }).catch(function (e) { say($('#rxOut'), e.message, 'err'); });
  }

  /* ---------- Radar ---------- */
  function tRadar() {
    api(pp('/radar')).then(function (r) {
      var cls = r.level === 'high' ? 'red' : r.level === 'medium' ? 'amber' : '';
      pane(H('Care Gap Radar') + '<div class="two"><div class="out"><span class="tag ' + cls + '">Care priority</span><div class="big" style="margin:10px 0">' + esc(r.level) + ' priority</div><p>' + esc(r.summary) + '</p><ul style="padding-left:20px;margin:10px 0 0">' + r.actions.map(function (a) { return '<li>' + esc(a) + '</li>'; }).join('') + '</ul></div>' +
        '<div><div class="card"><h3>What it looked at</h3><ul class="check" style="margin-top:10px"><li>' + r.inputs.missed_or_skipped + ' missed, skipped or unrecorded doses in 7 days</li><li>' + r.inputs.unanswered_checkins + ' unanswered check-ins in 7 days</li><li>Appointment in the next 3 days: ' + (r.inputs.appointment_soon ? 'yes' : 'no') + '</li></ul></div>' +
        '<div class="callout"><b>Boundary:</b> ' + esc(r.boundary) + '</div></div></div>');
    }).catch(fail);
  }

  /* ---------- Voice ---------- */
  var QS = { hi: ['Meri agli medicine kab hai?', 'Aaj ki medicines complete ho gayi?', 'Doctor appointment kab hai?', 'Maine medicine le li.', 'Caregiver ko update bhejo.'],
             en: ['When is my next medicine?', 'Did I finish today\'s medicines?', 'When is my doctor appointment?', 'I took my medicine.', 'Send an update to my caregiver.'] };
  var lastAns = '', pendingAction = null;
  function tVoice() {
    var SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    pane(H('Voice companion') + '<div class="two"><div><p style="margin-bottom:10px">Ask in Hindi or English. Answers come only from the saved profile.</p>' +
      '<div class="tabs" style="border:0;padding:0"><button class="tab" data-lang="hi" type="button" aria-selected="' + (S.lang === 'hi') + '">हिन्दी (Hinglish)</button><button class="tab" data-lang="en" type="button" aria-selected="' + (S.lang === 'en') + '">English</button></div>' +
      '<div class="chips" style="margin-bottom:12px">' + QS[S.lang].map(function (q, i) { return '<button class="chip" data-q="' + i + '" type="button">' + esc(q) + '</button>'; }).join('') + '</div>' +
      '<form id="vForm" class="row" style="align-items:center"><input id="vIn" type="text" placeholder="Type a question" aria-label="Question" style="flex:3 1 200px">' + (SR ? '<button class="btn small ghost" id="vMic" type="button" style="flex:0 0 auto">Speak</button>' : '') + '<button class="btn small" type="submit" style="flex:0 0 auto">Ask</button></form></div>' +
      '<div class="box"><div class="chat" id="chat" aria-live="polite"></div><div id="vConf" class="acts hide" style="margin-top:12px"><button class="btn small" id="vYes" type="button">Yes, do it</button><button class="btn small ghost" id="vNo" type="button">Cancel</button></div><button class="btn small ghost" id="vSpeak" type="button" style="margin-top:12px">Read last answer aloud</button></div></div>' +
      '<p style="font-size:.9rem;margin-top:12px">Anything that changes records asks you to confirm first.</p>');
    $$('[data-lang]').forEach(function (b) { b.addEventListener('click', function () { S.lang = b.getAttribute('data-lang'); tVoice(); }); });
    $$('[data-q]').forEach(function (b) { b.addEventListener('click', function () { ask(QS[S.lang][+b.getAttribute('data-q')]); }); });
    $('#vForm').addEventListener('submit', function (e) { e.preventDefault(); ask($('#vIn').value); $('#vIn').value = ''; });
    $('#vSpeak').addEventListener('click', function () { try { if (!lastAns || !window.speechSynthesis) return; var u = new SpeechSynthesisUtterance(lastAns); u.lang = S.lang === 'hi' ? 'hi-IN' : 'en-IN'; speechSynthesis.cancel(); speechSynthesis.speak(u); } catch (e) {} });
    $('#vYes').addEventListener('click', function () {
      if (!pendingAction) return;
      var a = pendingAction; pendingAction = null; $('#vConf').classList.add('hide');
      api(pp('/voice/confirm'), { method: 'POST', body: { action: a, lang: S.lang } }).then(function (d) { bub('bot', d.answer); lastAns = d.answer; }).catch(function (e) { bub('bot', e.message); });
    });
    $('#vNo').addEventListener('click', function () { pendingAction = null; $('#vConf').classList.add('hide'); bub('bot', S.lang === 'hi' ? 'Theek hai, cancel kar diya.' : 'Okay, cancelled.'); });
    var mic = $('#vMic');
    if (mic) mic.addEventListener('click', function () {
      try { var r = new SR(); r.lang = S.lang === 'hi' ? 'hi-IN' : 'en-IN'; r.onresult = function (ev) { ask(ev.results[0][0].transcript); }; r.onerror = function () { bar('Could not hear you. Type the question instead.', 'err'); }; r.start(); } catch (e) { bar('Voice input is not available here. Type instead.', 'err'); }
    });
  }
  function bub(c, t) { var d = document.createElement('div'); d.className = 'bubble ' + c; d.textContent = t; $('#chat').appendChild(d); }
  function ask(t) {
    t = (t || '').trim(); if (!t) return;
    bub('me', t);
    api(pp('/voice'), { method: 'POST', body: { text: t, lang: S.lang } }).then(function (d) {
      lastAns = d.answer; bub('bot', d.answer);
      pendingAction = d.needs_confirm ? d.action : null;
      $('#vConf').classList.toggle('hide', !d.needs_confirm);
    }).catch(function (e) { bub('bot', e.message); });
  }

  /* ---------- Family ---------- */
  function tFamily() {
    Promise.all([api(pp('/members')), api(pp('/feed')), can('manage_access') ? api(pp('/invites')) : Promise.resolve([])]).then(function (r) {
      var ms = r[0], feed = r[1], inv = r[2];
      var members = ms.map(function (m) {
        var ini = m.name.split(' ').map(function (w) { return w[0]; }).join('').slice(0, 2).toUpperCase();
        return '<div class="member' + (m.active ? '' : ' off') + '"><div class="av">' + esc(ini) + '</div><div><b>' + esc(m.name) + '</b> <span class="tag' + (m.active ? '' : ' grey') + '">' + (m.active ? esc(m.role) + (m.is_owner ? ' · owner' : '') : 'Access revoked') + '</span>' +
          (m.active ? '<div class="perms">' + m.permissions.map(function (p) { return '<span class="tag grey">' + esc(p.replace(/_/g, ' ')) + '</span>'; }).join('') + '</div>' : '') + '</div>' +
          (can('manage_access') && !m.is_owner ? '<button class="chip" data-m="' + m.id + '" data-on="' + (m.active ? 0 : 1) + '" type="button">' + (m.active ? 'Revoke' : 'Restore') + '</button>' : '<span></span>') + '</div>';
      }).join('');
      var invHtml = can('manage_access') ? '<form id="iForm" class="row" style="margin-top:14px"><label class="f" for="iRole">Invite as<select id="iRole"><option value="family">Family member</option><option value="caregiver">Caregiver</option><option value="elder">Elderly person</option></select></label><button class="btn small" type="submit" style="flex:0 0 auto">Create invite code</button></form><div id="iOut" aria-live="polite"></div>' +
        (inv.length ? '<p style="margin-top:10px;font-weight:600">Unused codes</p>' + inv.map(function (i) { return '<p><span class="mono">' + esc(i.code) + '</span> ' + esc(i.role) + '</p>'; }).join('') : '') : '<p style="margin-top:10px;font-size:.9rem">Only the profile owner can invite people or revoke access.</p>';
      pane(H('Family Connect') + '<div class="two"><div class="card"><h3>Who can see this care profile</h3>' + members + invHtml + '</div><div class="card"><h3>Activity feed &amp; audit history</h3><ul class="feed" style="margin-top:10px">' + feedHtml(feed) + '</ul></div></div>');
      $$('[data-m]').forEach(function (b) { b.addEventListener('click', function () { api(pp('/members/' + b.getAttribute('data-m')), { method: 'PATCH', body: { active: b.getAttribute('data-on') === '1' } }).then(tFamily).catch(fail); }); });
      var f = $('#iForm');
      if (f) f.addEventListener('submit', function (e) {
        e.preventDefault();
        api(pp('/invites'), { method: 'POST', body: { role: $('#iRole').value } }).then(function (d) {
          $('#iOut').innerHTML = '<div class="msg ok">Share this code: <span class="mono">' + esc(d.code) + '</span><br><small>They sign in, then choose "Join with an invite code".</small></div>';
        }).catch(fail);
      });
    }).catch(fail);
  }
  function feedHtml(feed) {
    return feed.length ? feed.map(function (f) { return '<li><time>' + esc(f.created_at.replace('T', ' ')) + '</time><span><b>' + esc(f.actor || 'System') + '</b>: ' + esc(f.event) + (f.detail ? ' (' + esc(f.detail) + ')' : '') + '</span></li>'; }).join('') : '<li><span>No activity yet.</span></li>';
  }

  /* ---------- Safety ---------- */
  var STEPS = ['Check-in due. A gentle prompt goes to the elderly person.', 'No response. Another reminder goes out.', 'Caregiver alert. The primary caregiver is notified.', 'Escalation. A secondary contact is notified if the alert is not acknowledged.'];
  function tSafety() {
    Promise.all([api(pp('/checkins')), api(pp('/alerts'))]).then(function (r) {
      var cs = r[0], al = r[1];
      var cur = cs[0];
      var steps = '';
      if (cur) {
        steps = '<ol class="steps" style="margin-top:12px">' + STEPS.map(function (s, i) {
          var cls = cur.status !== 'pending' ? (i < cur.level ? 'done' : '') : (i + 1 < cur.level ? 'done' : (i + 1 === cur.level ? 'now' : ''));
          return '<li class="' + cls + '"><span class="n">' + (i + 1) + '</span><span>' + esc(s) + '</span></li>';
        }).join('') + '</ol><p style="margin-top:10px;font-weight:600">Latest check-in (' + esc(cur.created_at.replace('T', ' ')) + '): ' + esc(cur.status) + (cur.note ? '. Note: ' + esc(cur.note) : '') + '</p>';
      }
      var acts = '';
      if (cur && cur.status === 'pending') {
        acts = '<div class="row" style="margin-top:12px">' + (can('respond_checkin') ? '<button class="btn small" id="ciYes" type="button" style="flex:0 0 auto">I am okay (respond)</button>' : '') +
          (can('ack') ? '<label class="f" for="ciNote" style="flex:2 1 220px">Follow-up note<input id="ciNote" type="text" placeholder="e.g. Called, she is fine"></label><button class="btn small ghost" id="ciAck" type="button" style="flex:0 0 auto">Acknowledge</button>' : '') + '</div>';
      }
      var alerts = al.length ? al.map(function (a) {
        return '<div class="alertitem' + (a.acked ? ' done' : '') + '"><b>' + esc(a.event) + '</b><br>' + esc(a.detail) + '<br><small>' + esc(a.created_at.replace('T', ' ')) + (a.acked ? ' · acknowledged by ' + esc(a.ack_by) + (a.ack_note ? ': ' + esc(a.ack_note) : '') : '') + '</small>' +
          (!a.acked && can('ack') ? '<div class="row" style="margin-top:8px"><input type="text" id="an' + a.id + '" placeholder="Follow-up note" aria-label="Follow-up note"><button class="btn small" data-ack="' + a.id + '" type="button" style="flex:0 0 auto">Acknowledge</button></div>' : '') + '</div>';
      }).join('') : '<p>No alerts for you.</p>';
      pane(H('Safety & escalation') + '<div class="two"><div class="card"><h3>Check-in and escalation</h3><p style="font-size:.95rem;margin:6px 0">Escalation steps happen after ' + 'the configured wait. A missing response alone is never treated as proof of an emergency.</p>' +
        (can('start_checkin') ? '<button class="btn small" id="ciStart" type="button">Start a check-in</button>' : '') + steps + acts + '</div>' +
        '<div style="display:grid;gap:18px;align-content:start"><div class="box" style="text-align:center"><h3 style="margin-bottom:10px">Emergency SOS</h3><button class="sos" id="sosBtn" type="button" aria-label="Open Emergency SOS">SOS</button><p style="margin-top:10px;font-size:.95rem">Notifies the other people with access. Not a replacement for emergency services. In an emergency call 112.</p></div>' +
        '<div class="card"><h3>Alerts for you</h3><div style="display:grid;gap:10px;margin-top:10px">' + alerts + '</div></div></div></div>');
      var go = function (id, fn) { var el = $(id); if (el) el.addEventListener('click', fn); };
      go('#ciStart', function () { api(pp('/checkins'), { method: 'POST' }).then(function () { bar('Check-in started.'); tSafety(); }).catch(fail); });
      go('#ciYes', function () { api(pp('/checkins/' + cur.id + '/respond'), { method: 'POST' }).then(tSafety).catch(fail); });
      go('#ciAck', function () { api(pp('/checkins/' + cur.id + '/ack'), { method: 'POST', body: { note: $('#ciNote').value } }).then(tSafety).catch(fail); });
      $$('[data-ack]').forEach(function (b) { b.addEventListener('click', function () { var id = b.getAttribute('data-ack'); api(pp('/alerts/' + id + '/ack'), { method: 'POST', body: { note: $('#an' + id).value } }).then(tSafety).catch(fail); }); });
      go('#sosBtn', function () { $('#sosModal').hidden = false; $('#sosNo').focus(); });
      S.timer = setInterval(function () { if (S.tab === 'safety' && $('#sosModal').hidden) tSafety(); }, 30000);
    }).catch(fail);
  }
  $('#sosNo').addEventListener('click', function () { $('#sosModal').hidden = true; });
  $('#sosYes').addEventListener('click', function () {
    $('#sosModal').hidden = true;
    api(pp('/sos'), { method: 'POST' }).then(function (d) { bar('Your care team was notified (' + d.notified + '). ' + d.message, 'ok'); }).catch(fail);
  });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') $('#sosModal').hidden = true; });

  /* ---------- Visits & Passport ---------- */
  function tVisits() {
    Promise.all([api(pp('/appointments')), api(pp('/passport'))]).then(function (r) {
      var ap = r[0], pass = r[1].text;
      var list = ap.length ? ap.map(function (a) {
        return '<div class="med"><div class="time" style="min-width:0">' + esc(a.when.replace('T', ' ')) + '</div><div><b>' + esc(a.doctor) + '</b><br><small>' + esc(a.notes) + '</small></div><div class="acts">' + (can('manage_appts') ? '<button class="chip" data-da="' + a.id + '" type="button">Remove</button>' : '') + '</div></div>';
      }).join('') : '<p>No upcoming appointments.</p>';
      var form = can('manage_appts') ? '<form id="aForm" class="row" style="margin-top:14px"><label class="f" for="aDoc">Doctor<input id="aDoc" type="text" required></label><label class="f" for="aWhen">Date and time<input id="aWhen" type="datetime-local" required></label><label class="f" for="aNotes">Notes<input id="aNotes" type="text"></label><button class="btn small" type="submit" style="flex:0 0 auto">Add</button></form>' : '';
      pane(H('Visits & Health Passport') + '<div class="two"><div class="card"><h3>Upcoming appointments</h3>' + list + form + '</div><div><div class="out"><pre id="passTxt" style="white-space:pre-wrap;margin:0;font-family:inherit;line-height:1.5">' + esc(pass) + '</pre></div><div class="row" style="margin-top:12px"><button class="btn small" id="passPrint" type="button" style="flex:0 0 auto">Print or save as PDF</button><button class="btn small ghost" id="passCopy" type="button" style="flex:0 0 auto">Copy</button></div></div></div>');
      $$('[data-da]').forEach(function (b) { b.addEventListener('click', function () { api(pp('/appointments/' + b.getAttribute('data-da')), { method: 'DELETE' }).then(tVisits).catch(fail); }); });
      var f = $('#aForm');
      if (f) f.addEventListener('submit', function (e) { e.preventDefault(); api(pp('/appointments'), { method: 'POST', body: { doctor: $('#aDoc').value, when: $('#aWhen').value, notes: $('#aNotes').value } }).then(tVisits).catch(fail); });
      $('#passPrint').addEventListener('click', function () {
        var w = window.open('', '_blank');
        if (!w) { bar('Pop-ups are blocked. Allow pop-ups to print.', 'err'); return; }
        w.document.write('<title>Health Passport</title><pre style="font:16px/1.6 sans-serif;white-space:pre-wrap;padding:24px">' + esc(pass) + '</pre>');
        w.document.close(); w.focus(); w.print();
      });
      $('#passCopy').addEventListener('click', function () { try { navigator.clipboard.writeText(pass).then(function () { bar('Copied.'); }); } catch (e) { bar('Copy is not available. Select the text and copy it.', 'err'); } });
    }).catch(fail);
  }

  /* ---------- start ---------- */
  if (S.token) { toProfiles(); } else { show('vAuth'); }
})();
