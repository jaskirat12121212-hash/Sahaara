import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import importlib.util
spec = importlib.util.spec_from_file_location("logic", os.path.join(os.path.dirname(__file__), "..", "app", "logic.py"))
L = importlib.util.module_from_spec(spec); spec.loader.exec_module(L)
from datetime import date, datetime
from types import SimpleNamespace as NS


def test_times_and_range():
    assert L.parse_times("20:00, 08:00,bad,8:00,08:00") == ["08:00", "20:00"]
    m = NS(start_date="2026-11-10", end_date="2026-11-20", times="09:00")
    assert L.doses_for_day(m, date(2026, 11, 9)) == []
    assert L.doses_for_day(m, date(2026, 11, 15)) == ["09:00"]
    assert L.doses_for_day(m, date(2026, 11, 21)) == []


def test_state_and_adherence():
    now = datetime(2026, 11, 15, 12, 0)
    d = date(2026, 11, 15)
    assert L.dose_state(None, d, "08:00", now) == "overdue"
    assert L.dose_state(None, d, "11:30", now) == "pending"
    assert L.dose_state("taken", d, "08:00", now) == "taken"
    assert L.adherence([]) is None
    assert L.adherence(["pending", "pending"]) is None
    assert L.adherence(["taken", "taken", "missed", "overdue"]) == 50


def test_refill():
    r = L.refill(18, 2, date(2026, 11, 15))
    assert r["days_left"] == 9 and r["run_out"] == "2026-11-24" and r["remind_on"] == "2026-11-19" and not r["low"]
    assert L.refill(8, 2, date(2026, 11, 15))["low"]
    assert L.refill(None, 2, date(2026, 11, 15)) is None


def test_radar():
    assert L.radar(0, 0, False)["level"] == "low"
    assert L.radar(1, 1, True)["level"] == "medium"
    assert L.radar(3, 2, True)["level"] == "high"
    r = L.radar(2, 0, False)
    assert "2 missed" in r["summary"] and "boundary" in r


def test_checkin_levels():
    assert [L.checkin_level(m) for m in (0, 14, 15, 29, 30, 59, 60, 500)] == [1, 1, 2, 2, 3, 3, 4, 4]


def test_roles():
    assert "manage_access" in L.CAPS["elder"] and "manage_access" not in L.CAPS["family"]
    assert "record_dose" in L.CAPS["caregiver"] and "manage_meds" not in L.CAPS["caregiver"]


def test_voice():
    assert L.voice_intent("Meri agli medicine kab hai?") == "next"
    assert L.voice_intent("Aaj ki medicines complete ho gayi?") == "progress"
    assert L.voice_intent("Doctor appointment kab hai?") == "appointment"
    assert L.voice_intent("Caregiver ko update bhejo.") == "notify"
    assert L.voice_intent("maine medicine le li") == "record"
    assert L.voice_intent("hello") == "unknown"
