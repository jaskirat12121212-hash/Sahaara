import os, smtplib
from email.message import EmailMessage


def send_email(to: str, subject: str, body: str) -> bool:
    """Send through SMTP when configured. Returns False (never raises) otherwise."""
    host = os.getenv("SMTP_HOST")
    if not host or not to:
        return False
    try:
        msg = EmailMessage()
        msg["From"] = os.getenv("SMTP_FROM", os.getenv("SMTP_USER", "alerts@sahaara360.local"))
        msg["To"] = to
        msg["Subject"] = subject
        msg.set_content(body)
        with smtplib.SMTP(host, int(os.getenv("SMTP_PORT", "587")), timeout=10) as s:
            s.starttls()
            if os.getenv("SMTP_USER"):
                s.login(os.getenv("SMTP_USER"), os.getenv("SMTP_PASSWORD", ""))
            s.send_message(msg)
        return True
    except Exception:
        return False
