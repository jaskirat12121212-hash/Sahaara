import os, hmac, hashlib, secrets, time
import jwt
from fastapi import Depends, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session
from .db import get_db
from .models import User

SECRET = os.getenv("SECRET_KEY", "dev-only-change-me")
TOKEN_HOURS = int(os.getenv("TOKEN_HOURS", "72"))
bearer = HTTPBearer(auto_error=False)


def hash_passcode(passcode: str) -> str:
    salt = secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac("sha256", passcode.encode(), salt.encode(), 200_000)
    return f"{salt}${dk.hex()}"


def check_passcode(passcode: str, stored: str) -> bool:
    try:
        salt, hexhash = stored.split("$", 1)
    except ValueError:
        return False
    dk = hashlib.pbkdf2_hmac("sha256", passcode.encode(), salt.encode(), 200_000)
    return hmac.compare_digest(dk.hex(), hexhash)


def make_token(user_id: int) -> str:
    return jwt.encode({"sub": str(user_id), "exp": int(time.time()) + TOKEN_HOURS * 3600},
                      SECRET, algorithm="HS256")


def current_user(cred: HTTPAuthorizationCredentials = Depends(bearer),
                 db: Session = Depends(get_db)) -> User:
    if not cred:
        raise HTTPException(401, "Sign in to continue.")
    try:
        data = jwt.decode(cred.credentials, SECRET, algorithms=["HS256"])
        user = db.get(User, int(data["sub"]))
    except Exception:
        raise HTTPException(401, "Your session expired. Sign in again.")
    if not user:
        raise HTTPException(401, "Account not found.")
    return user
