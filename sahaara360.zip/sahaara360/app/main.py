import os, re, json, base64, secrets, urllib.request
from contextlib import asynccontextmanager
from datetime import datetime, date, timedelta
from zoneinfo import ZoneInfo
from typing import List, Optional

from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from .db import Base, engine, get_db, SessionLocal
from .models import (User, Profile, Access, Invite, Medicine, DoseLog, Appointment,
                     Checkin, Alert)
from .security import hash_passcode, check_passcode, make_token, current_user
from .notify import send_email
from . import logic as L

TZ = ZoneInfo(os.getenv("TZ_NAME", "Asia/Kolkata"))
REMIND_MIN = int(os.getenv("CHECKIN_REMIND_MIN", "15"))
CAREGIVER_MIN = int(os.getenv("CHECKIN_CAREGIVER_MIN", "30"))
SECONDARY_MIN = int(os.getenv("CHECKIN_SECONDARY_MIN", "60"))
GRACE_MIN = int(os.getenv("MISSED_GRACE_MIN", "60"))

@asynccontextmanager
async def lifespan(_app):
    Base.metadata.create_all(engine)
    yield


app = FastAPI(title="SAHAARA 360 API", version="1.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=os.getenv("ALLOWED_ORIGINS", "*").split(","),
                   allow_methods=["*"], allow_headers=["*"])




def now() -> datetime:
    return datetime.now(TZ).replace(tzinfo=None)


# ---------------------------------------------------------------- helpers
def get_access(db: Session, user: User, pid: int, cap: Optional[str] = None) -> Access:
    a = db.query(Access).filter_by(profile_id=pid, user_id=user.id, active=True).first()
    if not a:
        raise HTTPException(403, "You do not have access to this profile.")
    if cap == "manage_access":
        if not a.is_owner:
            raise HTTPException(403, "Only the profile owner can manage access.")
    elif cap and cap not in L.CAPS[a.role]:
        raise HTTPException(403, f"Your role ({a.role}) cannot do this.")
    return a


def audit(db: Session, pid: int, actor: Optional[User], event: str, detail: str = ""):
    db.add(Alert(profile_id=pid, kind="audit", actor_id=actor.id if actor else None,
                 event=event, detail=detail, created_at=now()))
    db.commit()


def contacts(db: Session, pid: int):
    """Caregivers first, then family. First is the primary, second the secondary contact."""
    rows = db.query(Access).filter_by(profile_id=pid, active=True).order_by(Access.id).all()
    return [a for a in rows if a.role == "caregiver"] + [a for a in rows if a.role == "family"]


def make_alert(db: Session, pid: int, recipient_id: int, event: str, detail: str,
               key: Optional[str] = None, actor: Optional[User] = None):
    if key and db.query(Alert).filter_by(profile_id=pid, key=key, recipient_id=recipient_id).first():
        return None
    al = Alert(profile_id=pid, kind="alert", actor_id=actor.id if actor else None,
               recipient_id=recipient_id, event=event, detail=detail, key=key, created_at=now())
    r = db.get(User, recipient_id)
    if r:
        al.emailed = send_email(r.email, f"SAHAARA 360: {event}", detail)
    db.add(al)
    db.commit()
    return al


def week_states(db: Session, pid: int, days: int = 7):
    """(day, time, medicine, state) for the last `days` days up to now."""
    t = now()
    meds = db.query(Medicine).filter_by(profile_id=pid, active=True).all()
    start = t.date() - timedelta(days=days - 1)
    logs = {(l.medicine_id, l.day, l.time): l for l in
            db.query(DoseLog).filter(DoseLog.profile_id == pid, DoseLog.day >= start.isoformat()).all()}
    out = []
    for d in L.daterange(start, t.date()):
        for m in meds:
            for tm in L.doses_for_day(m, d):
                lg = logs.get((m.id, d.isoformat(), tm))
                st = L.dose_state(lg.status if lg else None, d, tm, t, GRACE_MIN)
                out.append((d, tm, m, st))
    return out


def med_out(m: Medicine):
    times = L.parse_times(m.times)
    return {"id": m.id, "name": m.name, "dosage": m.dosage, "times": times,
            "start_date": m.start_date, "end_date": m.end_date, "stock": m.stock,
            "active": m.active, "refill": L.refill(m.stock, len(times), now().date())}


def advance_checkin(db: Session, c: Checkin):
    if c.status != "pending":
        return c
    age = (now() - c.created_at).total_seconds() / 60
    lvl = L.checkin_level(age, REMIND_MIN, CAREGIVER_MIN, SECONDARY_MIN)
    if lvl > c.level:
        prof = db.get(Profile, c.profile_id)
        cs = contacts(db, c.profile_id)
        msg = (f"{prof.name} has not answered a check-in. Please call and confirm they are okay. "
               "A missing response alone is not proof of an emergency.")
        for step in range(c.level + 1, lvl + 1):
            if step == 3 and cs:
                make_alert(db, c.profile_id, cs[0].user_id, "Check-in not answered", msg, f"ci{c.id}-3")
            if step == 4:
                if len(cs) > 1:
                    make_alert(db, c.profile_id, cs[1].user_id, "Check-in still unacknowledged", msg, f"ci{c.id}-4")
                else:
                    audit(db, c.profile_id, None, "No secondary contact to escalate to",
                          "Invite another family member or caregiver.")
        c.level = lvl
        db.commit()
    return c


def checkin_out(c: Checkin):
    return {"id": c.id, "created_at": c.created_at.isoformat(timespec="minutes"), "status": c.status,
            "level": c.level, "note": c.note,
            "response_at": c.response_at.isoformat(timespec="minutes") if c.response_at else None}


def alert_out(a: Alert, names):
    return {"id": a.id, "kind": a.kind, "event": a.event, "detail": a.detail,
            "actor": names.get(a.actor_id), "recipient": names.get(a.recipient_id),
            "recipient_id": a.recipient_id, "emailed": a.emailed,
            "created_at": a.created_at.isoformat(timespec="minutes"),
            "acked": bool(a.ack_at), "ack_by": names.get(a.ack_by), "ack_note": a.ack_note}


def user_names(db: Session, pid: int):
    ids = [x.user_id for x in db.query(Access).filter_by(profile_id=pid).all()]
    return {u.id: u.name for u in db.query(User).filter(User.id.in_(ids)).all()} if ids else {}


def caps_for(a: Access):
    c = set(L.CAPS[a.role]) - {"manage_access"}
    if a.is_owner:
        c.add("manage_access")
    return sorted(c)


# ---------------------------------------------------------------- schemas
class RegisterIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    email: str = Field(min_length=5, max_length=200)
    passcode: str = Field(min_length=6, max_length=100)


class LoginIn(BaseModel):
    email: str
    passcode: str


class ProfileIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    age: Optional[int] = Field(None, ge=0, le=130)
    emergency_contacts: str = ""
    my_role: str = "elder"


class InviteIn(BaseModel):
    role: str


class RedeemIn(BaseModel):
    code: str


class MemberPatch(BaseModel):
    active: bool


class MedIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    dosage: str = ""
    times: List[str]
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    stock: Optional[int] = Field(None, ge=0)


class MedPatch(BaseModel):
    name: Optional[str] = None
    dosage: Optional[str] = None
    times: Optional[List[str]] = None
    end_date: Optional[str] = None
    stock: Optional[int] = Field(None, ge=0)
    active: Optional[bool] = None


class DoseIn(BaseModel):
    medicine_id: int
    time: str
    day: Optional[str] = None
    status: str  # taken | skipped | missed | clear


class ApptIn(BaseModel):
    doctor: str = Field(min_length=1, max_length=120)
    when: str
    notes: str = ""


class NoteIn(BaseModel):
    note: str = ""


class VoiceIn(BaseModel):
    text: str
    lang: str = "hi"


class VoiceConfirmIn(BaseModel):
    action: str
    lang: str = "hi"


# ---------------------------------------------------------------- auth
@app.post("/api/auth/register")
def register(b: RegisterIn, db: Session = Depends(get_db)):
    email = b.email.strip().lower()
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
        raise HTTPException(422, "Enter a valid email address.")
    if db.query(User).filter_by(email=email).first():
        raise HTTPException(409, "That email is already registered. Sign in instead.")
    u = User(name=b.name.strip(), email=email, pw_hash=hash_passcode(b.passcode))
    db.add(u)
    db.commit()
    return {"token": make_token(u.id), "user": {"id": u.id, "name": u.name, "email": u.email}}


@app.post("/api/auth/login")
def login(b: LoginIn, db: Session = Depends(get_db)):
    u = db.query(User).filter_by(email=b.email.strip().lower()).first()
    if not u or not check_passcode(b.passcode, u.pw_hash):
        raise HTTPException(401, "Email or passcode is not correct.")
    return {"token": make_token(u.id), "user": {"id": u.id, "name": u.name, "email": u.email}}


@app.get("/api/me")
def me(user: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = (db.query(Access, Profile).join(Profile, Profile.id == Access.profile_id)
            .filter(Access.user_id == user.id, Access.active == True).all())  # noqa: E712
    return {"user": {"id": user.id, "name": user.name, "email": user.email},
            "profiles": [{"id": p.id, "name": p.name, "age": p.age, "role": a.role,
                          "is_owner": a.is_owner, "caps": caps_for(a)}
                         for a, p in rows]}


# ---------------------------------------------------------------- profiles, access, invites
@app.post("/api/profiles")
def create_profile(b: ProfileIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    if b.my_role not in L.ROLES:
        raise HTTPException(422, "Role must be elder, family or caregiver.")
    p = Profile(name=b.name.strip(), age=b.age, emergency_contacts=b.emergency_contacts)
    db.add(p)
    db.flush()
    db.add(Access(profile_id=p.id, user_id=user.id, role=b.my_role, is_owner=True))
    db.commit()
    audit(db, p.id, user, "Profile created", p.name)
    return {"id": p.id}


@app.get("/api/profiles/{pid}/members")
def members(pid: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    get_access(db, user, pid, "view")
    rows = db.query(Access, User).join(User, User.id == Access.user_id).filter(Access.profile_id == pid).all()
    return [{"id": a.id, "name": u.name, "email": u.email, "role": a.role, "is_owner": a.is_owner,
             "active": a.active, "permissions": sorted(L.CAPS[a.role])} for a, u in rows]


@app.patch("/api/profiles/{pid}/members/{aid}")
def patch_member(pid: int, aid: int, b: MemberPatch, user: User = Depends(current_user),
                 db: Session = Depends(get_db)):
    get_access(db, user, pid, "manage_access")
    a = db.query(Access).filter_by(id=aid, profile_id=pid).first()
    if not a:
        raise HTTPException(404, "Member not found.")
    if a.is_owner:
        raise HTTPException(400, "The owner's access cannot be revoked.")
    a.active = b.active
    db.commit()
    u = db.get(User, a.user_id)
    audit(db, pid, user, ("Restored access for " if b.active else "Revoked access for ") + u.name)
    return {"ok": True}


@app.post("/api/profiles/{pid}/invites")
def create_invite(pid: int, b: InviteIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    get_access(db, user, pid, "manage_access")
    if b.role not in L.ROLES:
        raise HTTPException(422, "Role must be elder, family or caregiver.")
    code = secrets.token_urlsafe(6).replace("-", "A").replace("_", "B").upper()[:8]
    db.add(Invite(profile_id=pid, role=b.role, code=code, created_by=user.id))
    db.commit()
    audit(db, pid, user, f"Created an invite for a {b.role}")
    return {"code": code, "role": b.role}


@app.get("/api/profiles/{pid}/invites")
def list_invites(pid: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    get_access(db, user, pid, "manage_access")
    return [{"code": i.code, "role": i.role} for i in
            db.query(Invite).filter_by(profile_id=pid, used=False).all()]


@app.post("/api/invites/redeem")
def redeem(b: RedeemIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    inv = db.query(Invite).filter_by(code=b.code.strip().upper(), used=False).first()
    if not inv:
        raise HTTPException(404, "That invite code is not valid or was already used.")
    a = db.query(Access).filter_by(profile_id=inv.profile_id, user_id=user.id).first()
    if a and a.is_owner:
        raise HTTPException(400, "You already own this profile.")
    if a:
        a.role, a.active = inv.role, True
    else:
        db.add(Access(profile_id=inv.profile_id, user_id=user.id, role=inv.role))
    inv.used = True
    db.commit()
    audit(db, inv.profile_id, user, f"Joined as {inv.role}")
    return {"profile_id": inv.profile_id}


# ---------------------------------------------------------------- medicines & doses
@app.get("/api/profiles/{pid}/medicines")
def list_meds(pid: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    get_access(db, user, pid, "view")
    return [med_out(m) for m in db.query(Medicine).filter_by(profile_id=pid, active=True).order_by(Medicine.id)]


def clean_times(times):
    t = L.parse_times(",".join(times))
    if not t:
        raise HTTPException(422, "Add at least one time in 24-hour HH:MM format, for example 08:00.")
    return ",".join(t)


@app.post("/api/profiles/{pid}/medicines")
def add_med(pid: int, b: MedIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    get_access(db, user, pid, "manage_meds")
    m = Medicine(profile_id=pid, name=b.name.strip(), dosage=b.dosage.strip(), times=clean_times(b.times),
                 start_date=b.start_date or now().date().isoformat(), end_date=b.end_date, stock=b.stock)
    db.add(m)
    db.commit()
    audit(db, pid, user, f"Added medicine {m.name} {m.dosage}", f"Times: {m.times}")
    return med_out(m)


@app.patch("/api/profiles/{pid}/medicines/{mid}")
def edit_med(pid: int, mid: int, b: MedPatch, user: User = Depends(current_user), db: Session = Depends(get_db)):
    get_access(db, user, pid, "manage_meds")
    m = db.query(Medicine).filter_by(id=mid, profile_id=pid).first()
    if not m:
        raise HTTPException(404, "Medicine not found.")
    data = b.model_dump(exclude_unset=True)
    if "times" in data:
        data["times"] = clean_times(data["times"])
    for k, v in data.items():
        setattr(m, k, v)
    db.commit()
    audit(db, pid, user, f"Changed medicine {m.name}", ", ".join(data.keys()))
    return med_out(m)


@app.delete("/api/profiles/{pid}/medicines/{mid}")
def remove_med(pid: int, mid: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    get_access(db, user, pid, "manage_meds")
    m = db.query(Medicine).filter_by(id=mid, profile_id=pid).first()
    if not m:
        raise HTTPException(404, "Medicine not found.")
    m.active = False
    db.commit()
    audit(db, pid, user, f"Removed medicine {m.name}")
    return {"ok": True}


@app.get("/api/profiles/{pid}/schedule")
def schedule(pid: int, day: Optional[str] = None, user: User = Depends(current_user),
             db: Session = Depends(get_db)):
    get_access(db, user, pid, "view")
    t = now()
    d = date.fromisoformat(day) if day else t.date()
    logs = {(l.medicine_id, l.time): l for l in db.query(DoseLog).filter_by(profile_id=pid, day=d.isoformat())}
    names = user_names(db, pid)
    items = []
    for m in db.query(Medicine).filter_by(profile_id=pid, active=True):
        for tm in L.doses_for_day(m, d):
            lg = logs.get((m.id, tm))
            items.append({"medicine_id": m.id, "name": m.name, "dosage": m.dosage, "time": tm, "day": d.isoformat(),
                          "status": L.dose_state(lg.status if lg else None, d, tm, t, GRACE_MIN),
                          "recorded_by": names.get(lg.recorded_by) if lg else None})
    items.sort(key=lambda x: (x["time"], x["name"]))
    week = week_states(db, pid)
    nxt = next((i for i in items if i["status"] in ("pending", "overdue")), None)
    return {"day": d.isoformat(), "items": items, "next": nxt,
            "taken": sum(1 for i in items if i["status"] == "taken"), "total": len(items),
            "adherence_today": L.adherence([i["status"] for i in items]),
            "adherence_7d": L.adherence([s for _, _, _, s in week])}


@app.post("/api/profiles/{pid}/doses")
def record_dose(pid: int, b: DoseIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    get_access(db, user, pid, "record_dose")
    if b.status not in ("taken", "skipped", "missed", "clear"):
        raise HTTPException(422, "Status must be taken, skipped, missed or clear.")
    m = db.query(Medicine).filter_by(id=b.medicine_id, profile_id=pid, active=True).first()
    if not m:
        raise HTTPException(404, "Medicine not found.")
    day = b.day or now().date().isoformat()
    if b.time not in L.doses_for_day(m, date.fromisoformat(day)):
        raise HTTPException(422, "That dose is not on the schedule.")
    lg = db.query(DoseLog).filter_by(medicine_id=m.id, day=day, time=b.time).first()
    was_taken = bool(lg and lg.status == "taken")
    if b.status == "clear":
        if lg:
            db.delete(lg)
    elif lg:
        lg.status, lg.recorded_by, lg.recorded_at = b.status, user.id, now()
    else:
        db.add(DoseLog(medicine_id=m.id, profile_id=pid, day=day, time=b.time, status=b.status,
                       recorded_by=user.id, recorded_at=now()))
    now_taken = b.status == "taken"
    if m.stock is not None:
        if now_taken and not was_taken:
            m.stock = max(0, m.stock - 1)
        elif was_taken and not now_taken:
            m.stock += 1
    db.commit()
    audit(db, pid, user, f"Recorded {m.name} {m.dosage} at {b.time} as {b.status}" if b.status != "clear"
          else f"Cleared record for {m.name} at {b.time}")
    return {"ok": True}


# ---------------------------------------------------------------- prescription scanner (draft only)
RX_PROMPT = ('Read this prescription image. Return ONLY JSON: a list of objects with keys '
             '"name" (medicine), "dosage" (like "500 mg") and "times" (list of 24-hour HH:MM times per day, '
             'guess from frequency such as once daily=["09:00"], twice daily=["08:00","20:00"]). '
             'If something is unreadable, leave it empty. Do not invent medicines.')


@app.post("/api/profiles/{pid}/prescriptions/extract")
def extract_prescription(pid: int, file: UploadFile = File(...), user: User = Depends(current_user),
                         db: Session = Depends(get_db)):
    get_access(db, user, pid, "manage_meds")
    key = os.getenv("GEMINI_API_KEY")
    if not key:
        raise HTTPException(503, "Prescription scanning needs a GEMINI_API_KEY on the server. "
                                 "Add the medicines by hand for now.")
    data = file.file.read()
    if len(data) > 6_000_000:
        raise HTTPException(413, "Image is larger than 6 MB.")
    model = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")
    body = {"contents": [{"parts": [{"text": RX_PROMPT},
                                    {"inline_data": {"mime_type": file.content_type or "image/jpeg",
                                                     "data": base64.b64encode(data).decode()}}]}],
            "generationConfig": {"response_mime_type": "application/json"}}
    req = urllib.request.Request(
        f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={key}",
        data=json.dumps(body).encode(), headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=40) as r:
            txt = json.loads(r.read())["candidates"][0]["content"]["parts"][0]["text"]
        rows = json.loads(txt)
        draft = [{"name": str(x.get("name", ""))[:120], "dosage": str(x.get("dosage", ""))[:60],
                  "times": L.parse_times(",".join(x.get("times") or []))} for x in rows if isinstance(x, dict)]
    except Exception:
        raise HTTPException(502, "Could not read the prescription. Try a clearer photo or add it by hand.")
    audit(db, pid, user, "Scanned a prescription (draft, not saved)")
    return {"draft": draft, "note": "Draft only. Verify every field before saving."}


# ---------------------------------------------------------------- appointments
@app.get("/api/profiles/{pid}/appointments")
def list_appts(pid: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    get_access(db, user, pid, "view")
    today = now().strftime("%Y-%m-%dT%H:%M")
    rows = db.query(Appointment).filter(Appointment.profile_id == pid, Appointment.when >= today).order_by(Appointment.when)
    return [{"id": a.id, "doctor": a.doctor, "when": a.when, "notes": a.notes} for a in rows]


@app.post("/api/profiles/{pid}/appointments")
def add_appt(pid: int, b: ApptIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    get_access(db, user, pid, "manage_appts")
    try:
        datetime.strptime(b.when, "%Y-%m-%dT%H:%M")
    except ValueError:
        raise HTTPException(422, "Date and time must look like 2026-11-18T11:00.")
    a = Appointment(profile_id=pid, doctor=b.doctor.strip(), when=b.when, notes=b.notes)
    db.add(a)
    db.commit()
    audit(db, pid, user, f"Added appointment with {a.doctor}", a.when.replace("T", " "))
    return {"id": a.id}


@app.delete("/api/profiles/{pid}/appointments/{aid}")
def del_appt(pid: int, aid: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    get_access(db, user, pid, "manage_appts")
    a = db.query(Appointment).filter_by(id=aid, profile_id=pid).first()
    if not a:
        raise HTTPException(404, "Appointment not found.")
    db.delete(a)
    db.commit()
    audit(db, pid, user, f"Removed appointment with {a.doctor}")
    return {"ok": True}


# ---------------------------------------------------------------- check-ins, alerts, SOS
@app.post("/api/profiles/{pid}/checkins")
def start_checkin(pid: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    get_access(db, user, pid, "start_checkin")
    c = Checkin(profile_id=pid, created_at=now())
    db.add(c)
    db.commit()
    audit(db, pid, user, "Check-in prompt sent to the elderly person")
    return checkin_out(c)


@app.get("/api/profiles/{pid}/checkins")
def list_checkins(pid: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    get_access(db, user, pid, "view")
    rows = db.query(Checkin).filter_by(profile_id=pid).order_by(Checkin.id.desc()).limit(10).all()
    return [checkin_out(advance_checkin(db, c)) for c in rows]


@app.post("/api/profiles/{pid}/checkins/{cid}/respond")
def respond_checkin(pid: int, cid: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    get_access(db, user, pid, "respond_checkin")
    c = db.query(Checkin).filter_by(id=cid, profile_id=pid).first()
    if not c:
        raise HTTPException(404, "Check-in not found.")
    c.status, c.response_at = "answered", now()
    db.commit()
    audit(db, pid, user, "Answered the check-in")
    return checkin_out(c)


@app.post("/api/profiles/{pid}/checkins/{cid}/ack")
def ack_checkin(pid: int, cid: int, b: NoteIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    get_access(db, user, pid, "ack")
    c = db.query(Checkin).filter_by(id=cid, profile_id=pid).first()
    if not c:
        raise HTTPException(404, "Check-in not found.")
    if c.status == "pending":
        c.status = "acknowledged"
    c.ack_by, c.note = user.id, b.note
    db.commit()
    audit(db, pid, user, "Acknowledged a check-in alert and added a follow-up note", b.note)
    return checkin_out(c)


@app.get("/api/profiles/{pid}/alerts")
def my_alerts(pid: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    get_access(db, user, pid, "view")
    names = user_names(db, pid)
    rows = (db.query(Alert).filter(Alert.profile_id == pid, Alert.kind == "alert", Alert.recipient_id == user.id)
            .order_by(Alert.id.desc()).limit(20).all())
    return [alert_out(a, names) for a in rows]


@app.post("/api/profiles/{pid}/alerts/{aid}/ack")
def ack_alert(pid: int, aid: int, b: NoteIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    get_access(db, user, pid, "ack")
    a = db.query(Alert).filter_by(id=aid, profile_id=pid, kind="alert").first()
    if not a:
        raise HTTPException(404, "Alert not found.")
    a.ack_by, a.ack_at, a.ack_note = user.id, now(), b.note
    # acknowledging a check-in alert stops the escalation
    m = re.match(r"ci(\d+)-", a.key or "")
    if m:
        c = db.get(Checkin, int(m.group(1)))
        if c and c.status == "pending":
            c.status, c.ack_by, c.note = "acknowledged", user.id, b.note
    db.commit()
    audit(db, pid, user, f"Acknowledged alert: {a.event}", b.note)
    return {"ok": True}


@app.post("/api/profiles/{pid}/sos")
def sos(pid: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    get_access(db, user, pid, "sos")
    prof = db.get(Profile, pid)
    others = [a for a in contacts(db, pid) if a.user_id != user.id]
    for a in others:
        make_alert(db, pid, a.user_id, "SOS pressed",
                   f"{user.name} pressed SOS for {prof.name}. Call them now. If it is an emergency, call 112. "
                   "SAHAARA 360 is not a replacement for emergency services.", actor=user)
    audit(db, pid, user, "SOS pressed", f"{len(others)} contact(s) notified")
    return {"notified": len(others), "message": "If this is an emergency, call 112 now."}


@app.get("/api/profiles/{pid}/feed")
def feed(pid: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    get_access(db, user, pid, "view")
    names = user_names(db, pid)
    rows = (db.query(Alert).filter(Alert.profile_id == pid, (Alert.kind == "audit") | (Alert.recipient_id == None))  # noqa: E711
            .order_by(Alert.id.desc()).limit(40).all())
    return [alert_out(a, names) for a in rows]


# ---------------------------------------------------------------- care gap radar
@app.get("/api/profiles/{pid}/radar")
def radar(pid: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    get_access(db, user, pid, "view")
    missed = sum(1 for _, _, _, s in week_states(db, pid) if s in ("missed", "skipped", "overdue"))
    since = now() - timedelta(days=7)
    unanswered = db.query(Checkin).filter(Checkin.profile_id == pid, Checkin.created_at >= since,
                                          Checkin.response_at == None, Checkin.level >= 2).count()  # noqa: E711
    soon = now() + timedelta(days=3)
    appt = db.query(Appointment).filter(Appointment.profile_id == pid,
                                        Appointment.when >= now().strftime("%Y-%m-%dT%H:%M"),
                                        Appointment.when <= soon.strftime("%Y-%m-%dT%H:%M")).count() > 0
    r = L.radar(missed, unanswered, appt)
    r["inputs"] = {"missed_or_skipped": missed, "unanswered_checkins": unanswered, "appointment_soon": appt}
    return r


# ---------------------------------------------------------------- voice companion
def _t(lang, hi, en):
    return hi if lang == "hi" else en


@app.post("/api/profiles/{pid}/voice")
def voice(pid: int, b: VoiceIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    get_access(db, user, pid, "view")
    s = schedule(pid, None, user, db)
    lang, intent = b.lang, L.voice_intent(b.text)
    out = {"intent": intent, "needs_confirm": False, "action": None}
    nxt = s["next"]
    if intent == "next":
        out["answer"] = (_t(lang, f"Aapki agli medicine {nxt['name']} {nxt['dosage']} hai, {nxt['time']} par.",
                            f"Your next medicine is {nxt['name']} {nxt['dosage']} at {nxt['time']}.")
                         if nxt else _t(lang, "Aaj ki saari medicines record ho chuki hain.",
                                        "All of today's medicines are recorded."))
    elif intent == "progress":
        left = s["total"] - s["taken"]
        out["answer"] = _t(lang, f"Aaj {s['total']} mein se {s['taken']} medicines li gayi hain, {left} baaki hain.",
                           f"{s['taken']} of {s['total']} medicines are taken today, {left} are left.")
    elif intent == "appointment":
        a = list_appts(pid, user, db)
        out["answer"] = (_t(lang, f"Aapki agli appointment {a[0]['doctor']} ke saath {a[0]['when'].replace('T', ' ')} par hai.",
                            f"Your next appointment is with {a[0]['doctor']} on {a[0]['when'].replace('T', ' ')}.")
                         if a else _t(lang, "Koi appointment saved nahin hai.", "There is no appointment saved."))
    elif intent == "notify":
        out.update(needs_confirm=True, action="notify",
                   answer=_t(lang, "Kya main caregiver ko aaj ka update bhejun? Confirm kijiye.",
                             "Shall I send today's update to the caregivers? Please confirm."))
    elif intent == "record":
        if nxt:
            out.update(needs_confirm=True, action="record",
                       answer=_t(lang, f"{nxt['name']} {nxt['time']} ki dose 'li gayi' record karun? Confirm kijiye.",
                                 f"Record {nxt['name']} at {nxt['time']} as taken? Please confirm."))
        else:
            out["answer"] = _t(lang, "Record karne ke liye koi dose baaki nahin hai.", "There is no dose left to record.")
    else:
        out["answer"] = _t(lang, "Main medicines, appointment aur caregiver update ke baare mein bata sakta hoon.",
                           "I can help with medicines, appointments and caregiver updates.")
    return out


@app.post("/api/profiles/{pid}/voice/confirm")
def voice_confirm(pid: int, b: VoiceConfirmIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    lang = b.lang
    if b.action == "notify":
        get_access(db, user, pid, "note")
        s = schedule(pid, None, user, db)
        prof = db.get(Profile, pid)
        text = f"{prof.name}: {s['taken']} of {s['total']} doses taken today."
        if s["next"]:
            text += f" Next: {s['next']['name']} at {s['next']['time']}."
        cs = [a for a in contacts(db, pid) if a.user_id != user.id]
        for a in cs:
            make_alert(db, pid, a.user_id, f"Update from {user.name}", text, actor=user)
        audit(db, pid, user, "Sent a caregiver update by voice", f"{len(cs)} recipient(s)")
        return {"answer": _t(lang, f"Update {len(cs)} contacts ko bhej diya gaya.", f"Update sent to {len(cs)} contact(s).")}
    if b.action == "record":
        get_access(db, user, pid, "record_dose")
        s = schedule(pid, None, user, db)
        n = s["next"]
        if not n:
            raise HTTPException(409, "No dose left to record.")
        record_dose(pid, DoseIn(medicine_id=n["medicine_id"], time=n["time"], day=n["day"], status="taken"), user, db)
        return {"answer": _t(lang, f"{n['name']} record kar li gayi.", f"Recorded {n['name']} as taken.")}
    raise HTTPException(422, "Unknown action.")


# ---------------------------------------------------------------- health passport
@app.get("/api/profiles/{pid}/passport")
def passport(pid: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    get_access(db, user, pid, "view")
    p = db.get(Profile, pid)
    meds = list_meds(pid, user, db)
    s = schedule(pid, None, user, db)
    ap = list_appts(pid, user, db)
    lines = [f"HEALTH PASSPORT", f"Name: {p.name}" + (f", {p.age}" if p.age else ""),
             f"Emergency contacts: {p.emergency_contacts or 'not set'}", "", "Medicines"]
    lines += [f"- {m['name']} {m['dosage']} at {', '.join(m['times'])}" for m in meds] or ["- none saved"]
    a7 = s["adherence_7d"]
    lines += ["", f"Adherence (last 7 days): {a7}%" if a7 is not None else "Adherence (last 7 days): not enough data"]
    lines += [f"Next appointment: {ap[0]['doctor']}, {ap[0]['when'].replace('T', ' ')}" if ap else "Next appointment: none saved",
              "", f"Prepared {now().strftime('%d %b %Y %H:%M')}. Contains only information the person has authorized. "
              "Not a medical record."]
    return {"text": "\n".join(lines)}


# ---------------------------------------------------------------- scheduled job (call from a cron)
@app.post("/api/jobs/tick")
def tick(x_job_key: Optional[str] = Header(None)):
    key = os.getenv("JOB_KEY")
    if not key or x_job_key != key:
        raise HTTPException(403, "Invalid job key.")
    db = SessionLocal()
    try:
        for c in db.query(Checkin).filter_by(status="pending").all():
            advance_checkin(db, c)
        t = now()
        created = 0
        for m in db.query(Medicine).filter_by(active=True).all():
            for tm in L.doses_for_day(m, t.date()):
                has = db.query(DoseLog).filter_by(medicine_id=m.id, day=t.date().isoformat(), time=tm).first()
                if has or L.dose_state(None, t.date(), tm, t, GRACE_MIN) != "overdue":
                    continue
                prof = db.get(Profile, m.profile_id)
                for a in contacts(db, m.profile_id):
                    if make_alert(db, m.profile_id, a.user_id, "Missed dose",
                                  f"{prof.name} has not recorded {m.name} {m.dosage} due at {tm}.",
                                  f"missed:{m.id}:{t.date()}:{tm}"):
                        created += 1
        return {"ok": True, "missed_dose_alerts": created}
    finally:
        db.close()


@app.get("/api/health")
def health():
    return {"ok": True}


FRONTEND = os.path.join(os.path.dirname(__file__), "..", "frontend")
app.mount("/", StaticFiles(directory=FRONTEND, html=True), name="frontend")
