"""Pure care logic: no database, no web. Easy to test and to explain to judges."""
import re
from datetime import date, datetime, timedelta

CAPS = {
    "elder":     {"view", "record_dose", "manage_meds", "manage_appts", "manage_access",
                  "respond_checkin", "ack", "sos", "note", "start_checkin"},
    "family":    {"view", "manage_meds", "manage_appts", "ack", "note", "start_checkin", "sos"},
    "caregiver": {"view", "record_dose", "ack", "note", "start_checkin", "sos"},
}
ROLES = tuple(CAPS)


def parse_times(s):
    out = []
    for t in (s or "").split(","):
        t = t.strip()
        if re.fullmatch(r"([01]\d|2[0-3]):[0-5]\d", t):
            out.append(t)
    return sorted(set(out))


def daterange(start: date, end: date):
    d = start
    while d <= end:
        yield d
        d += timedelta(days=1)


def doses_for_day(med, day: date):
    """Scheduled (time) slots of a medicine on a given day. `med` needs start_date, end_date, times."""
    if day.isoformat() < med.start_date:
        return []
    if med.end_date and day.isoformat() > med.end_date:
        return []
    return parse_times(med.times)


def dose_state(status, day: date, time: str, now: datetime, grace_min=60):
    """status from the log, or derived: pending / overdue."""
    if status:
        return status
    due = datetime.combine(day, datetime.strptime(time, "%H:%M").time())
    return "overdue" if now > due + timedelta(minutes=grace_min) else "pending"


def adherence(statuses):
    """Percent taken out of recorded-or-overdue doses. None when nothing to measure."""
    counted = [s for s in statuses if s in ("taken", "skipped", "missed", "overdue")]
    if not counted:
        return None
    return round(100 * sum(1 for s in counted if s == "taken") / len(counted))


def refill(stock, per_day, today: date):
    if stock is None or not per_day:
        return None
    days = stock // per_day
    run = today + timedelta(days=days)
    remind = today + timedelta(days=max(0, days - 5))
    return {"days_left": days, "run_out": run.isoformat(),
            "remind_on": remind.isoformat(), "low": days <= 5}


def radar(missed: int, unanswered: int, appt_soon: bool):
    score = missed * 2 + unanswered * 3 + (1 if appt_soon else 0)
    level = "high" if score >= 8 else "medium" if score >= 4 else "low"
    signals = []
    if missed:
        signals.append(f"{missed} missed or skipped dose{'s' if missed != 1 else ''} in the last 7 days")
    if unanswered:
        signals.append(f"{unanswered} unanswered check-in{'s' if unanswered != 1 else ''}")
    if appt_soon:
        signals.append("an appointment in the next 3 days")
    actions = []
    if unanswered:
        actions.append("Call the person and confirm how they are doing.")
    if missed >= 2:
        actions.append("Ask what is making doses hard to take, and tell the doctor if it continues.")
    if appt_soon:
        actions.append("Prepare questions and arrange transport or support for the visit.")
    if not actions:
        actions.append("Nothing to do. Keep the usual routine.")
    summary = (f"Care events seen together: {', '.join(signals)}. Flagged {level} for a caregiver to review."
               if signals else "No care gaps found. Routines look on track.")
    return {"level": level, "score": score, "summary": summary, "signals": signals,
            "actions": actions,
            "boundary": "This is a prompt for a human to review. It is not a diagnosis, "
                        "a safety decision or a change to any prescription."}


def checkin_level(age_min: float, remind=15, caregiver=30, secondary=60):
    if age_min >= secondary:
        return 4
    if age_min >= caregiver:
        return 3
    if age_min >= remind:
        return 2
    return 1


# ---- voice intents (Hindi/Hinglish and English) ----
def voice_intent(text: str):
    q = (text or "").lower()
    if re.search(r"\b(update|bhejo|bhej do|send)\b", q):
        return "notify"
    if re.search(r"(le li|le liya|kha li|kha liya|i took|i have taken|mark.*taken|record.*dose)", q):
        return "record"
    if re.search(r"appointment|doctor|daktar|dr\.", q):
        return "appointment"
    if re.search(r"complete|done|ho gayi|ho gaya|finish|how many|kitni", q):
        return "progress"
    if re.search(r"medicine|dawai|dawa|dose|agli|next|goli", q):
        return "next"
    return "unknown"
