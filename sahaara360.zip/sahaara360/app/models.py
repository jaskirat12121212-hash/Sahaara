from datetime import datetime
from sqlalchemy import (Column, Integer, String, Text, Boolean, DateTime, ForeignKey,
                        UniqueConstraint)
from .db import Base


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    name = Column(String(120), nullable=False)
    email = Column(String(200), unique=True, nullable=False, index=True)
    pw_hash = Column(String(300), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)


class Profile(Base):
    __tablename__ = "profiles"
    id = Column(Integer, primary_key=True)
    name = Column(String(120), nullable=False)
    age = Column(Integer)
    emergency_contacts = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)


class Access(Base):
    """Care Access: who can see a profile and with which role."""
    __tablename__ = "access"
    id = Column(Integer, primary_key=True)
    profile_id = Column(Integer, ForeignKey("profiles.id"), index=True, nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), index=True, nullable=False)
    role = Column(String(20), nullable=False)  # elder | family | caregiver
    is_owner = Column(Boolean, default=False)
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    __table_args__ = (UniqueConstraint("profile_id", "user_id"),)


class Invite(Base):
    __tablename__ = "invites"
    id = Column(Integer, primary_key=True)
    profile_id = Column(Integer, ForeignKey("profiles.id"), nullable=False)
    role = Column(String(20), nullable=False)
    code = Column(String(20), unique=True, nullable=False)
    used = Column(Boolean, default=False)
    created_by = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime, default=datetime.utcnow)


class Medicine(Base):
    __tablename__ = "medicines"
    id = Column(Integer, primary_key=True)
    profile_id = Column(Integer, ForeignKey("profiles.id"), index=True, nullable=False)
    name = Column(String(120), nullable=False)
    dosage = Column(String(60), default="")
    times = Column(String(120), nullable=False)  # "08:00,20:00"
    start_date = Column(String(10), nullable=False)  # YYYY-MM-DD
    end_date = Column(String(10))
    stock = Column(Integer)
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class DoseLog(Base):
    __tablename__ = "dose_logs"
    id = Column(Integer, primary_key=True)
    medicine_id = Column(Integer, ForeignKey("medicines.id"), nullable=False)
    profile_id = Column(Integer, ForeignKey("profiles.id"), index=True, nullable=False)
    day = Column(String(10), nullable=False)
    time = Column(String(5), nullable=False)
    status = Column(String(10), nullable=False)  # taken | skipped | missed
    recorded_by = Column(Integer, ForeignKey("users.id"))
    recorded_at = Column(DateTime, default=datetime.utcnow)
    __table_args__ = (UniqueConstraint("medicine_id", "day", "time"),)


class Appointment(Base):
    __tablename__ = "appointments"
    id = Column(Integer, primary_key=True)
    profile_id = Column(Integer, ForeignKey("profiles.id"), index=True, nullable=False)
    doctor = Column(String(120), nullable=False)
    when = Column(String(16), nullable=False)  # YYYY-MM-DDTHH:MM
    notes = Column(Text, default="")


class Checkin(Base):
    __tablename__ = "checkins"
    id = Column(Integer, primary_key=True)
    profile_id = Column(Integer, ForeignKey("profiles.id"), index=True, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)  # stored in app-local time
    status = Column(String(15), default="pending")  # pending | answered | acknowledged
    level = Column(Integer, default=1)  # 1 prompt, 2 reminder, 3 caregiver, 4 secondary
    response_at = Column(DateTime)
    ack_by = Column(Integer, ForeignKey("users.id"))
    note = Column(Text, default="")


class Alert(Base):
    """Both the audit trail (kind=audit) and notifications (kind=alert)."""
    __tablename__ = "alerts"
    id = Column(Integer, primary_key=True)
    profile_id = Column(Integer, ForeignKey("profiles.id"), index=True, nullable=False)
    kind = Column(String(10), default="audit")
    actor_id = Column(Integer, ForeignKey("users.id"))
    recipient_id = Column(Integer, ForeignKey("users.id"))
    event = Column(String(200), nullable=False)
    detail = Column(Text, default="")
    key = Column(String(120), index=True)  # dedupe key for generated alerts
    emailed = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    ack_by = Column(Integer, ForeignKey("users.id"))
    ack_at = Column(DateTime)
    ack_note = Column(Text, default="")
